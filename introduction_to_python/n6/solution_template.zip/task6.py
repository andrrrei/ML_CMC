def check(x: str, file: str):
    pass

