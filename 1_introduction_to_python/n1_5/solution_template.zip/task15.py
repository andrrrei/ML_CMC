from typing import List


def hello(name: str) -> str:
    pass


def int_to_roman(num: int) -> str:
    pass


def longest_common_prefix(strs_input: List[str]) -> str:
    pass


def primes() -> int:
    yield


class BankCard:
    def __init__(self, total_sum: int, balance_limit: int):
        pass

